import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'

import * as commentActions from '../../actions/index'
import Like from '../../images/like.png'
import Dislike from '../../images/dislike.png'
import { formatTimeStamp } from '../../utils/Extras'

class CommentPost extends Component {

    onDeleteComment = (comment) => {
        let parentId = comment.parentId
        this.props.deleteComment(comment.id, () => {
            this.props.history.push(`/post/${parentId}`)
            this.props.fetchCommentForPost(comment.parentId)
        })
    }

    render() {
        return(
            <div>
                {this.props.comments.map(comment => (
                    <div className="comment-2" key={comment.id}>
                        <div>
                            <div className="comment-style">
                                {comment.body}
                                </div>
                            <div className="comment-style">
                                <p>
                                    at {formatTimeStamp(comment.timestamp)}by
                                    <b>{comment.author}</b>
                                </p>
                            </div>
                            <div className="comment-style">
                                <img src={Like}
                                     height="30"
                                     width="30"
                                     onClick={() => {
                                    this.props.voteComment(comment.id, comment.parentId, "upVote")}}
                                />
                                <img src={Dislike}
                                     height="30"
                                     width="30"
                                     onClick={() => {
                                    this.props.voteComment(comment.id, comment.parentId, "downVote")}}
                                />
                                {comment.voteScore} votes
                            </div>
                            <div className="button-action">
                                <Link to={`/${this.props.category}/${comment.parentId}/${comment.id}/edit`}>
                                    <button>Edit Comment</button>
                                </Link>
                                <button
                                    onClick={() => this.onDeleteComment(comment)}>
                                    Delete Comment
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        )
    }
}

function mapStateToProps({ posts }) {
    return { posts }
}

export default connect(mapStateToProps, commentActions)(CommentPost)