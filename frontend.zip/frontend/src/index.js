import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware, compose } from 'redux'
import { BrowserRouter } from 'react-router-dom'
import { Provider } from 'react-redux'
import thunk from 'redux-thunk'

import './index.css';
import App from './components/App';
import reducer from '../src/reducers/index'
import registerServiceWorker from './registerServiceWorker';

const logger = store => next => action => {
    let output = next(action)
    return output
}

const composers = compose || window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__

const store = createStore(
    reducer,
    composers(
        applyMiddleware(logger, thunk)
    )
)

ReactDOM.render(
    <BrowserRouter>
        <Provider store={store}>
            <App />
        </Provider>
    </BrowserRouter>
    , document.getElementById('root'));
registerServiceWorker();
